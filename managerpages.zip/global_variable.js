const baseURL = 'www.baidu.com'
const islogin = 0

export default {
  baseURL,
  islogin
}
