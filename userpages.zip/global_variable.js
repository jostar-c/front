const baseURL = 'https://www.baidu.com/'
const islogin = 1

export default {
  baseURL,
  islogin
}
